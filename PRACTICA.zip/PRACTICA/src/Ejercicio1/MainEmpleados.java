package Ejercicio1;

public class MainEmpleados {
    public static void main(String[] args) {
        
        Empleado empleadoFullTime = new EmpleadoTiempoCompleto("Carlos Gómez", 3500, 700);
        Empleado empleadoPorHoras = new EmpleadoPorHoras("Luisa Martínez", 0, 120, 18.50);
        
        System.out.println("\n--- Empleado a Tiempo Completo ---");
        empleadoFullTime.mostrarInformacion();
        
        System.out.println("\n--- Empleado por Horas ---");
        empleadoPorHoras.mostrarInformacion();
    }
}
