package Ejercicio3;

public class KadaneAlgorithm {
    public int maxSubarraySum(int[] numeros) {
        if (numeros == null || numeros.length == 0) return 0;
        
        int maxActual = numeros[0];
        int maxGlobal = numeros[0];
        
        for (int i = 1; i < numeros.length; i++) {
            maxActual = Math.max(numeros[i], maxActual + numeros[i]);
            maxGlobal = Math.max(maxGlobal, maxActual);
        }
        return maxGlobal;
    }
}
