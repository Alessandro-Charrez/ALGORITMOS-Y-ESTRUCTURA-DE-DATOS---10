package Ejercicio3;

public class Main {
    public static void main(String[] args) {
        int[] numeros = {3, -2, 5, -1, 6, -3, 2, 7};
        int objetivo = 9;

        SumaObjetivo sumaObj = new SumaObjetivo();
        boolean existe = sumaObj.existeSumaObjetivo(numeros, objetivo);
        System.out.println("¿Existe una pareja que sume " + objetivo + "? " + (existe ? "Sí" : "No"));

        KadaneAlgorithm kadane = new KadaneAlgorithm();
        int sumaMaxima = kadane.maxSubarraySum(numeros);
        System.out.println("Suma máxima de subarreglo contiguo: " + sumaMaxima);
    }
}