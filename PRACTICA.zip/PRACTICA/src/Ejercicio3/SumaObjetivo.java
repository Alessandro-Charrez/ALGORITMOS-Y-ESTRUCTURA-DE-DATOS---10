package Ejercicio3;

import java.util.HashSet;

public class SumaObjetivo {
    public boolean existeSumaObjetivo(int[] numeros, int objetivo) {
        HashSet<Integer> complementos = new HashSet<>();
        for (int num : numeros) {
            if (complementos.contains(num)) return true;
            complementos.add(objetivo - num);
        }
        return false;
    }
}
