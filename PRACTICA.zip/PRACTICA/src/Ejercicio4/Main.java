package Ejercicio4;

public class Main {
    public static void main(String[] args) {
        Fibonacci fib = new Fibonacci();
        int n = 30;

        // Recursivo 
        long inicioRec = System.currentTimeMillis();
        int resultadoRec = fib.fibonacciRecursivo(n);
        long finRec = System.currentTimeMillis();
        System.out.println("Fibonacci recursivo de " + n + " es: " + resultadoRec);
        System.out.println("Tiempo recursivo: " + (finRec - inicioRec) + " ms");

        // Con memorización
        long inicioMemo = System.currentTimeMillis();
        int resultadoMemo = fib.fibonacciMemo(n);
        long finMemo = System.currentTimeMillis();
        System.out.println("Fibonacci con memorizacion de " + n + " es: " + resultadoMemo);
        System.out.println("Tiempo con memorizacion: " + (finMemo - inicioMemo) + " ms");
    }
}