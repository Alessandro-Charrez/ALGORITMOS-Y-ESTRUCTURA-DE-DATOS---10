package Ejercicio4;

import java.util.HashMap;
import java.util.Map;

public class Fibonacci {
    // Recursiva
    public int fibonacciRecursivo(int n) {
        if (n < 0) throw new IllegalArgumentException("n debe ser >= 0");
        if (n <= 1) return n;
        return fibonacciRecursivo(n - 1) + fibonacciRecursivo(n - 2);
    }

    // Con memorización
    private Map<Integer, Integer> cache = new HashMap<>();
    
    public int fibonacciMemo(int n) {
        if (n < 0) throw new IllegalArgumentException("n debe ser >= 0");
        if (n <= 1) return n;
        if (cache.containsKey(n)) return cache.get(n);
        
        int resultado = fibonacciMemo(n - 1) + fibonacciMemo(n - 2);
        cache.put(n, resultado);
        return resultado;
    }
}
