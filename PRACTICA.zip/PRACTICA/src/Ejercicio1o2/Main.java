package Ejercicio1o2;

import java.util.ArrayList;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        // Crear una lista de vehículos
        ArrayList<Vehiculo> vehiculos = new ArrayList<>();

        vehiculos.add(new Automovil("Toyota", "Corolla", 2020, 50000, true));
        vehiculos.add(new Automovil("Honda", "Civic", 2018, 70000, false));

        vehiculos.add(new Motocicleta("Yamaha", "FZ", 2021, 250));
        vehiculos.add(new Motocicleta("Kawasaki", "Ninja", 2019, 600));

        System.out.println("Vehículos y su costo de mantenimiento:");
        for (Vehiculo v : vehiculos) {
            System.out.println(v.getClass().getSimpleName() + " - " + v.marca + " " + v.modelo +
                               " (" + v.anio + ") - Costo mantenimiento: S/." + v.calcularCostoMantenimiento());
        }

        // Ordenar los vehículos por costo de mantenimiento
        Collections.sort(vehiculos, Vehiculo::compararPorCostoMantenimiento);

        System.out.println("\nVehículos ordenados por costo de mantenimiento:");
        for (Vehiculo v : vehiculos) {
            System.out.println(v.getClass().getSimpleName() + " - " + v.marca + " " + v.modelo +
                               " - Costo: $" + v.calcularCostoMantenimiento());
        }
    }
}