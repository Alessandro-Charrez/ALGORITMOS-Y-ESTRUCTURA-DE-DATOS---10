package Ejercicio1o2;

public class Automovil extends Vehiculo {
    private double kilometraje;
    private boolean tieneAireAcondicionado;

    public Automovil(String marca, String modelo, int anio, double kilometraje, boolean tieneAireAcondicionado) {
        super(marca, modelo, anio);
        this.kilometraje = kilometraje;
        this.tieneAireAcondicionado = tieneAireAcondicionado;
    }

    @Override
    public double calcularCostoMantenimiento() {
        double costoBase = kilometraje * 0.05;
        return tieneAireAcondicionado ? costoBase + 100 : costoBase;
    }
}

