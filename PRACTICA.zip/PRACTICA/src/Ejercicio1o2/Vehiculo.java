package Ejercicio1o2;

public abstract class Vehiculo {
    protected String marca;
    protected String modelo;
    protected int anio;

    public Vehiculo(String marca, String modelo, int anio) {
        this.marca = marca;
        this.modelo = modelo;
        this.anio = anio;
    }

    public abstract double calcularCostoMantenimiento();

    public static int compararPorCostoMantenimiento(Vehiculo v1, Vehiculo v2) {
        return Double.compare(v1.calcularCostoMantenimiento(), v2.calcularCostoMantenimiento());
    }
}
