package Ejercicio2;

public class Main {
    public static void main(String[] args) {
        // Contenedor de Strings
        Contenedor<String> contenedorStrings = new Contenedor<>();
        contenedorStrings.agregar("Hola");
        contenedorStrings.agregar("Mundo");
        contenedorStrings.agregar("Java");

        System.out.println("Contenedor de Strings:");
        for (int i = 0; i < contenedorStrings.contar(); i++) {
            System.out.println(contenedorStrings.obtener(i));
        }
        System.out.println("¿Está vacío?: " + contenedorStrings.estaVacio());
        System.out.println();

        // Contenedor de Productos
        Contenedor<Producto> contenedorProductos = new Contenedor<>();
        contenedorProductos.agregar(new Producto("Laptop", 1500.0));
        contenedorProductos.agregar(new Producto("Mouse", 25.0));
        contenedorProductos.agregar(new Producto("Teclado", 45.0));

        System.out.println("Contenedor de Productos:");
        for (int i = 0; i < contenedorProductos.contar(); i++) {
            System.out.println(contenedorProductos.obtener(i));
        }
        System.out.println("¿Está vacío?: " + contenedorProductos.estaVacio());
    }
}