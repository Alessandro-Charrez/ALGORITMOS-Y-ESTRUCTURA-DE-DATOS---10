package Ejercicio4o2;

public class MergeSort {
    public void mergeSort(int[] array) {
        if (array == null || array.length <= 1) return;
        mergeSort(array, 0, array.length - 1);
    }

    private void mergeSort(int[] array, int inicio, int fin) {
        if (inicio < fin) {
            int medio = inicio + (fin - inicio) / 2;
            mergeSort(array, inicio, medio);
            mergeSort(array, medio + 1, fin);
            merge(array, inicio, medio, fin);
        }
    }

    private void merge(int[] array, int inicio, int medio, int fin) {
        int[] temp = new int[fin - inicio + 1];
        int i = inicio, j = medio + 1, k = 0;

        while (i <= medio && j <= fin) {
            temp[k++] = array[i] <= array[j] ? array[i++] : array[j++];
        }

        while (i <= medio) temp[k++] = array[i++];
        while (j <= fin) temp[k++] = array[j++];

        System.arraycopy(temp, 0, array, inicio, temp.length);
    }
}
