package Ejercicio4o2;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        MergeSort mergeSort = new MergeSort();
        int[] numeros = {38, 27, 43, 3, 9, 82, 10};

        System.out.println("Arreglo original:");
        System.out.println(Arrays.toString(numeros));

        mergeSort.mergeSort(numeros);

        System.out.println("Arreglo ordenado con MergeSort:");
        System.out.println(Arrays.toString(numeros));
    }
}