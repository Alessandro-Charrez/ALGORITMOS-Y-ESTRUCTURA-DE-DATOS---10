package Ejercicio2o2;

import Ejercicio2.Contenedor;

public class Main {
    public static void main(String[] args) {
        // Crear un contenedor de pares (nombre, edad)
        Contenedor<Par<String, Integer>> contenedor = new Contenedor<>();

        contenedor.agregar(new Par<>("Alice", 30));
        contenedor.agregar(new Par<>("Bob", 25));
        contenedor.agregar(new Par<>("Charlie", 40));


        System.out.println("Elementos en el contenedor:");
        for (int i = 0; i < contenedor.contar(); i++) {
            System.out.println(contenedor.obtener(i));
        }

        System.out.println("\nCantidad de elementos: " + contenedor.contar());
        System.out.println("¿El contenedor está vacío? " + contenedor.estaVacio());
    }
}